<?php
// Inclua o arquivo de conexão
include('conexao.php');

// Verificação das credenciais
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Preparar e executar a query de inserção
    $stmt = $conexao->prepare("INSERT INTO cadastros (usuarios, password) VALUES (?, ?)");
    if (!$stmt) {
        die("Erro na preparação da consulta: " . $conexao->error);
    }

    // Bind dos parâmetros
    $stmt->bind_param("ss", $username, $password);

    if ($stmt->execute()) {
        // Registro inserido com sucesso, redirecionar para a página de sucesso
        header("Location: Login.html");
        exit();
    } else {
        // Erro ao inserir registro, redirecionar para a página de cadastro com mensagem de erro
        header("Location: cadastro.html?error=1");
        exit();
    }
}

// Feche a conexão com o banco de dados
$conexao->close();
?>
