<?php
include('conexao.php');

// Verificação das credenciais
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prevenir SQL injection usando prepared statements
    $query = "SELECT * FROM cadastros WHERE usuarios = ? AND password = ?";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // Credenciais corretas, redirecionar para a página de sucesso
        header("Location: index.html");
        exit();
    } else {
        // Credenciais incorretas, redirecionar para a página de login com mensagem de erro
        header("Location: Login.html?error=1");
        exit();
    }
}

$conexao->close();
?>
